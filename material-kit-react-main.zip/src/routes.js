import { Navigate, useRoutes } from 'react-router-dom';
import { useSelector } from 'react-redux';

// layouts
import DashboardLayout from './layouts/dashboard';
import SimpleLayout from './layouts/simple';

// pages
import BlogPage from './pages/BlogPage';
import UserPage from './pages/UserPage';
import LoginPage from './pages/LoginPage';
import Page404 from './pages/Page404';
import ProductsPage from './pages/ProductsPage';
import DashboardAppPage from './pages/DashboardAppPage';
import Register from './pages/Register';
import OtpVerification from './pages/OtpVerification';
import UpdateProfile from './pages/UpdateUser';

// Redux selector
import { selectIsLoggedIn } from './fetures/ProfileSlice/selectIsLoggedIn'; // Replace with the actual path to your selectors

export default function Router() {
  const isLoggedIn = useSelector(selectIsLoggedIn);

  const routes = useRoutes([
    {
      path: '/dashboard',
      element: isLoggedIn ? <DashboardLayout /> : <Navigate to="/login" replace />,
      children: [
        { element: <Navigate to="/dashboard/app" />, index: true },
        { path: 'app', element: <DashboardAppPage /> },
        { path: 'user', element: <UserPage /> },
        // { path: 'products', element: <ProductsPage /> },
        { path: 'blog', element: <BlogPage /> },
      ],
    },
    {
      path: '/login',
      element: isLoggedIn ? <Navigate to="/dashboard/app" replace /> : <LoginPage />,
    },
    {
      path: '/updateProfile',
      element: isLoggedIn ? <UpdateProfile /> : <Navigate to="/login" replace />,
    },
    {
      element: <SimpleLayout />,
      children: [
        { element: <Navigate to="/dashboard/app" />, index: true },
        { path: '404', element: <Page404 /> },
        { path: '*', element: <Navigate to="/404" /> },
      ],
    },
    {
      path: '/404',
      element: <Page404 />,
    },
    {
      path: '/otp',
      element: isLoggedIn ? <Navigate to="/dashboard/app" replace /> : <OtpVerification />,
    },
    {
      path: '/',
      element: isLoggedIn ? <Navigate to="/dashboard/app" replace /> : <Navigate to="/login" />,
    },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
  ]);

  return routes;
}
