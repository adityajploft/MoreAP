import axios from "axios";
export default axios.create({
  baseURL: "https://stage.tasksplan.com/more-app/public/api",
});